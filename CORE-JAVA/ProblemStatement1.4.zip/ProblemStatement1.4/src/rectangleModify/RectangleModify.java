package rectangleModify;


import java.util.Scanner;

public class RectangleModify {
	int length; 
    int breadth; 
    int area; 
    int parameter;
    
    public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth() {
		return breadth;
	}

	public void setWidth(int width) {
		this.breadth = breadth;
	}

	
    public RectangleModify()
    {
    	length = 1;
    	breadth= 1;
    }

   public void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }
    
    void  areaRectangle()
    {
        area = length * breadth;
       
    }
 
     void  perimeterRectangle()
    {
    	 parameter = 2*(length + breadth);
       
    }

    void display() {
    	if(length>0 && length<20)
        {
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Parameter of Rectangle = " +parameter);}
       
        }

    public static void main(String args[]) {
    	
    	RectangleModify o = new RectangleModify();
        o.input();
        o.areaRectangle();
        o.perimeterRectangle();
        o.display();
        System.out.println(" ");
        RectangleModify o1 = new RectangleModify();
        o1.input();
        o1.areaRectangle();
        o1.perimeterRectangle();
        o1.display();
        System.out.println(" ");
        RectangleModify o2 = new RectangleModify();
        o2.input();
        o2.areaRectangle();
        o2.perimeterRectangle();
        o2.display();
        System.out.println(" ");
        RectangleModify o3 = new RectangleModify();
        o3.input();
        o3.areaRectangle();
        o3.perimeterRectangle();
        o3.display();
        System.out.println(" ");
        RectangleModify o4 = new RectangleModify();
        o4.input();
        o4.areaRectangle();
        o4.perimeterRectangle();
        o4.display();	
    }
}
