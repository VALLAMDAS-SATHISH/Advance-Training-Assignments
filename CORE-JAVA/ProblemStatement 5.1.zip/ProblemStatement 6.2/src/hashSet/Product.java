package hashSet;

import java.util.Hashtable;
import java.util.Scanner;

public class Product {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		Hashtable<String,String> sc = new Hashtable<String,String>();
		System.out.println("Enter the product id and name;");
		
		for(int i=0;i<3;i++) {
			sc.put(scan.next(),scan.next());
		}
		
		System.out.println("The product list is:");
		System.out.println(sc);
		System.out.println("Enter the product id to be removed:");
		
		String id = scan.next();
		sc.remove(id);
		
		System.out.println("Item removed");
		System.out.println("The product list is:");
		System.out.println(sc.toString());
		System.out.println("Enter the product id to be searched:");
		
		String sid=scan.next();
		
		if(sc.containsKey(sid)) {
			System.out.println(sc.get(sid));
		}
		else {
			System.out.println("Do not exist");
		}
		scan.close();
	}

}
