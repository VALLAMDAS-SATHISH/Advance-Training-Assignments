package arrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentArrayList {

	
	public static void main(String[] args) {
		
		ArrayList<String> a1=new ArrayList<String>();
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the no of students:");
		int n=scan.nextInt();
		
		System.out.println("Enter student's names:");
		for(int i=0;i<n;i++) {
			a1.add(scan.next());
		}
		
		for(String a:a1) {
			
			System.out.println("Enter name of the student to be searched:");
		    String students =scan.next(); 
		    int position = Collections.binarySearch(a1,students);
			System.out.println("Location of " + students + " is: " + position);
		}
	}

}
