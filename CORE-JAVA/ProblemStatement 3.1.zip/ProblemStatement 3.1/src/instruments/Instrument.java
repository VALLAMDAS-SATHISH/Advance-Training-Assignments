package instruments;

public abstract class Instrument {
	public abstract void play();

}
