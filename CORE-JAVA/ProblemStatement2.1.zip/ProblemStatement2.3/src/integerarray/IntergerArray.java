package integerarray;

import java.util.Arrays;

public class IntergerArray {

	public static void main(String[] args) {
		
		int[] array = new int[] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };
		int[] copiedArray = Arrays.copyOf(array, array.length);
		
		int total = 0, sum = 0, i;
		double average;
		
		for (i = 0; i < 14; i++) {
			sum = sum + array[i];
		}
		array[15] = sum;
		System.out.println("Sum of elements from index 0 to 14: " + array[15]);
		
		for (i = 0; i < array.length; i++) {
			total = total + array[i];
		}
		
		average = total / array.length;
		array[16] = (int) average;
		System.out.println("Average of all numbers: " + array[16]);
		
		Arrays.sort(copiedArray);
		array[17] = array[0];
		System.out.println("Smallest value from the array: " + array[17]);
		
		for (i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}

}
