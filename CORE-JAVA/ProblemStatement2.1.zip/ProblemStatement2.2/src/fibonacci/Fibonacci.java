package fibonacci;
import java.util.Scanner;

public class Fibonacci {
	
	public static void main(String[] args) {
		
		int n,n1, n2,n3,i;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the 1st no:");
		n1=scan.nextInt();
		
		System.out.println("Enter the 2nd no:");
		n2=scan.nextInt();
		
		System.out.println("Enter the total no of numbers to be printed:");
		n=scan.nextInt();
		scan.close();
		
		System.out.println(" " +n1);
		System.out.println(" " +n2);
		for(i=0;i<n;i++) {
			n3=n1+n2;
			System.out.println(" "+n3);
			n1=n2;
			n2=n3;
			
		}
		
		
	}

}
