package palindrome;
import java.util.Scanner;
public class Palindrome {
	
	public static void main(String[] args) {
		
		String string,reverse="";
		int i,length;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a String:");
		string =scan.nextLine();
		
		System.out.println(string.toUpperCase());//converting string to Uppercase//
		scan.close();
		
		
		length =string.length();
		System.out.println("Length:" +length);
		
		for (i=length-1;i>=0;i--) {
			reverse = reverse+string.charAt(i);
			
		}
		
		if (string.equals(reverse)) {
			System.out.println(string +" is a palindrome");
		}
		else {
			System.out.println(string +"is not a palindrome");
		}
		
		
		
	}

}
